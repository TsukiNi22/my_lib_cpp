#----------------------------------------------------------------
# Generated CMake target import file for configuration "Asan".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "utils::utils" for configuration "Asan"
set_property(TARGET utils::utils APPEND PROPERTY IMPORTED_CONFIGURATIONS ASAN)
set_target_properties(utils::utils PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_ASAN "CXX"
  IMPORTED_LOCATION_ASAN "${_IMPORT_PREFIX}/lib/libutils_asan.a"
  )

list(APPEND _cmake_import_check_targets utils::utils )
list(APPEND _cmake_import_check_files_for_utils::utils "${_IMPORT_PREFIX}/lib/libutils_asan.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
